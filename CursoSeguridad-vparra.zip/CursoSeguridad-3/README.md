<<<<<<< HEAD
# Practica del Modulo de Desarrollo Web Seguro.

## Instrucciones

Para poder ejecutar el proyecto es necesario tener instalado en el equipo de computo lo siguiente:

1. Apache Maven
2. Netbeans IDE 8.1
3. JDK 1.8

Para poder correr el servidor solo se requiere el siguiente comando:

`mvn exec:java -Dexec.mainClass="mx.uach.practicaseguridad.*"`

Donde:

mvn: Es el comando para ejecutar Maven.
exec:java -Dexec.mainClass: Especifica la clase que contiene el main en el proyecto.

Ejemplo:

`mvn exec:java -Dexec.mainClass="mx.uach.practicaseguridad.Login"`
=======
# Repositorio-vparra
Repositorio de Victor Parra
>>>>>>> origin/master
